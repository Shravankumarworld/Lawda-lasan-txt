from os import environ

API_ID = int(environ.get("API_ID", "26805575"))
API_HASH = environ.get("API_HASH", "0c741c6d5b5fd5eb360b653f0841990a")
BOT_TOKEN = environ.get("7410346111:AAEEdnj-673IIrjg1LjY1fhqyhriRvCCUdI", "")
